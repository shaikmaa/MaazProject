﻿namespace A1MaazShaikh
{
    partial class SoccerL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SoccerL));
            this.grpST = new System.Windows.Forms.GroupBox();
            this.grpGB = new System.Windows.Forms.GroupBox();
            this.rbCS = new System.Windows.Forms.RadioButton();
            this.rbAS = new System.Windows.Forms.RadioButton();
            this.rbBY = new System.Windows.Forms.RadioButton();
            this.rbLP = new System.Windows.Forms.RadioButton();
            this.rbSU = new System.Windows.Forms.RadioButton();
            this.grpGA = new System.Windows.Forms.GroupBox();
            this.rbFH = new System.Windows.Forms.RadioButton();
            this.rbAV = new System.Windows.Forms.RadioButton();
            this.rbET = new System.Windows.Forms.RadioButton();
            this.rbWF = new System.Windows.Forms.RadioButton();
            this.rbMU = new System.Windows.Forms.RadioButton();
            this.grpSTM = new System.Windows.Forms.GroupBox();
            this.lblSTB = new System.Windows.Forms.Label();
            this.lblSTA = new System.Windows.Forms.Label();
            this.lblWinner = new System.Windows.Forms.Label();
            this.lblFR = new System.Windows.Forms.Label();
            this.btnPlay = new System.Windows.Forms.Button();
            this.lblVS = new System.Windows.Forms.Label();
            this.lblTB = new System.Windows.Forms.Label();
            this.lblTA = new System.Windows.Forms.Label();
            this.imgTeamB = new System.Windows.Forms.PictureBox();
            this.imgTeamA = new System.Windows.Forms.PictureBox();
            this.btnR = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.grpCB = new System.Windows.Forms.GroupBox();
            this.rbCheatBurn = new System.Windows.Forms.RadioButton();
            this.rbCheatMan = new System.Windows.Forms.RadioButton();
            this.grpST.SuspendLayout();
            this.grpGB.SuspendLayout();
            this.grpGA.SuspendLayout();
            this.grpSTM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgTeamB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgTeamA)).BeginInit();
            this.grpCB.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpST
            // 
            this.grpST.BackColor = System.Drawing.Color.Black;
            this.grpST.Controls.Add(this.grpGB);
            this.grpST.Controls.Add(this.grpGA);
            this.grpST.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpST.ForeColor = System.Drawing.Color.White;
            this.grpST.Location = new System.Drawing.Point(12, 24);
            this.grpST.Name = "grpST";
            this.grpST.Size = new System.Drawing.Size(303, 250);
            this.grpST.TabIndex = 0;
            this.grpST.TabStop = false;
            this.grpST.Text = "Select Teams";
            // 
            // grpGB
            // 
            this.grpGB.Controls.Add(this.rbCS);
            this.grpGB.Controls.Add(this.rbAS);
            this.grpGB.Controls.Add(this.rbBY);
            this.grpGB.Controls.Add(this.rbLP);
            this.grpGB.Controls.Add(this.rbSU);
            this.grpGB.ForeColor = System.Drawing.Color.Purple;
            this.grpGB.Location = new System.Drawing.Point(157, 33);
            this.grpGB.Name = "grpGB";
            this.grpGB.Size = new System.Drawing.Size(128, 199);
            this.grpGB.TabIndex = 1;
            this.grpGB.TabStop = false;
            this.grpGB.Text = "Group B";
            // 
            // rbCS
            // 
            this.rbCS.AutoSize = true;
            this.rbCS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbCS.Location = new System.Drawing.Point(6, 159);
            this.rbCS.Name = "rbCS";
            this.rbCS.Size = new System.Drawing.Size(85, 24);
            this.rbCS.TabIndex = 4;
            this.rbCS.Text = "Chelsea";
            this.rbCS.UseVisualStyleBackColor = true;
            this.rbCS.CheckedChanged += new System.EventHandler(this.RbCS_CheckedChanged);
            // 
            // rbAS
            // 
            this.rbAS.AutoSize = true;
            this.rbAS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbAS.Location = new System.Drawing.Point(6, 125);
            this.rbAS.Name = "rbAS";
            this.rbAS.Size = new System.Drawing.Size(81, 24);
            this.rbAS.TabIndex = 3;
            this.rbAS.Text = "Arsenal";
            this.rbAS.UseVisualStyleBackColor = true;
            this.rbAS.CheckedChanged += new System.EventHandler(this.RbAS_CheckedChanged);
            // 
            // rbBY
            // 
            this.rbBY.AutoSize = true;
            this.rbBY.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbBY.Location = new System.Drawing.Point(7, 91);
            this.rbBY.Name = "rbBY";
            this.rbBY.Size = new System.Drawing.Size(80, 24);
            this.rbBY.TabIndex = 2;
            this.rbBY.Text = "Burnley";
            this.rbBY.UseVisualStyleBackColor = true;
            this.rbBY.CheckedChanged += new System.EventHandler(this.RbBY_CheckedChanged);
            // 
            // rbLP
            // 
            this.rbLP.AutoSize = true;
            this.rbLP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbLP.Location = new System.Drawing.Point(7, 57);
            this.rbLP.Name = "rbLP";
            this.rbLP.Size = new System.Drawing.Size(90, 24);
            this.rbLP.TabIndex = 1;
            this.rbLP.Text = "Liverpool";
            this.rbLP.UseVisualStyleBackColor = true;
            this.rbLP.CheckedChanged += new System.EventHandler(this.RbLP_CheckedChanged);
            // 
            // rbSU
            // 
            this.rbSU.AutoSize = true;
            this.rbSU.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbSU.Location = new System.Drawing.Point(7, 23);
            this.rbSU.Name = "rbSU";
            this.rbSU.Size = new System.Drawing.Size(90, 24);
            this.rbSU.TabIndex = 0;
            this.rbSU.Text = "Sheffield";
            this.rbSU.UseVisualStyleBackColor = true;
            this.rbSU.CheckedChanged += new System.EventHandler(this.RbSU_CheckedChanged);
            // 
            // grpGA
            // 
            this.grpGA.Controls.Add(this.rbFH);
            this.grpGA.Controls.Add(this.rbAV);
            this.grpGA.Controls.Add(this.rbET);
            this.grpGA.Controls.Add(this.rbWF);
            this.grpGA.Controls.Add(this.rbMU);
            this.grpGA.ForeColor = System.Drawing.Color.LawnGreen;
            this.grpGA.Location = new System.Drawing.Point(17, 33);
            this.grpGA.Name = "grpGA";
            this.grpGA.Size = new System.Drawing.Size(125, 199);
            this.grpGA.TabIndex = 0;
            this.grpGA.TabStop = false;
            this.grpGA.Text = "Group A";
            this.grpGA.Enter += new System.EventHandler(this.GrpGA_Enter);
            // 
            // rbFH
            // 
            this.rbFH.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbFH.Location = new System.Drawing.Point(7, 159);
            this.rbFH.Name = "rbFH";
            this.rbFH.Size = new System.Drawing.Size(85, 25);
            this.rbFH.TabIndex = 4;
            this.rbFH.Text = "Fulham";
            this.rbFH.UseVisualStyleBackColor = true;
            this.rbFH.CheckedChanged += new System.EventHandler(this.RbFH_CheckedChanged);
            // 
            // rbAV
            // 
            this.rbAV.AutoSize = true;
            this.rbAV.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbAV.Location = new System.Drawing.Point(6, 125);
            this.rbAV.Name = "rbAV";
            this.rbAV.Size = new System.Drawing.Size(102, 24);
            this.rbAV.TabIndex = 3;
            this.rbAV.Text = "Aston Villa";
            this.rbAV.UseVisualStyleBackColor = true;
            this.rbAV.CheckedChanged += new System.EventHandler(this.RbAV_CheckedChanged);
            // 
            // rbET
            // 
            this.rbET.AutoSize = true;
            this.rbET.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbET.Location = new System.Drawing.Point(6, 57);
            this.rbET.Name = "rbET";
            this.rbET.Size = new System.Drawing.Size(82, 24);
            this.rbET.TabIndex = 2;
            this.rbET.Text = "Everton";
            this.rbET.UseVisualStyleBackColor = true;
            this.rbET.CheckedChanged += new System.EventHandler(this.RbET_CheckedChanged);
            // 
            // rbWF
            // 
            this.rbWF.AutoSize = true;
            this.rbWF.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbWF.Location = new System.Drawing.Point(7, 91);
            this.rbWF.Name = "rbWF";
            this.rbWF.Size = new System.Drawing.Size(89, 24);
            this.rbWF.TabIndex = 1;
            this.rbWF.Text = "WatFord\r\n";
            this.rbWF.UseVisualStyleBackColor = true;
            this.rbWF.CheckedChanged += new System.EventHandler(this.RbWF_CheckedChanged);
            // 
            // rbMU
            // 
            this.rbMU.AutoSize = true;
            this.rbMU.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbMU.Location = new System.Drawing.Point(6, 25);
            this.rbMU.Name = "rbMU";
            this.rbMU.Size = new System.Drawing.Size(111, 24);
            this.rbMU.TabIndex = 0;
            this.rbMU.Text = "Manchester";
            this.rbMU.UseVisualStyleBackColor = true;
            this.rbMU.CheckedChanged += new System.EventHandler(this.RbMU_CheckedChanged);
            // 
            // grpSTM
            // 
            this.grpSTM.BackColor = System.Drawing.Color.Black;
            this.grpSTM.Controls.Add(this.lblSTB);
            this.grpSTM.Controls.Add(this.lblSTA);
            this.grpSTM.Controls.Add(this.lblWinner);
            this.grpSTM.Controls.Add(this.lblFR);
            this.grpSTM.Controls.Add(this.btnPlay);
            this.grpSTM.Controls.Add(this.lblVS);
            this.grpSTM.Controls.Add(this.lblTB);
            this.grpSTM.Controls.Add(this.lblTA);
            this.grpSTM.Controls.Add(this.imgTeamB);
            this.grpSTM.Controls.Add(this.imgTeamA);
            this.grpSTM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpSTM.ForeColor = System.Drawing.Color.White;
            this.grpSTM.Location = new System.Drawing.Point(321, 24);
            this.grpSTM.Name = "grpSTM";
            this.grpSTM.Size = new System.Drawing.Size(439, 326);
            this.grpSTM.TabIndex = 1;
            this.grpSTM.TabStop = false;
            this.grpSTM.Text = "Soccer Team Match";
            // 
            // lblSTB
            // 
            this.lblSTB.BackColor = System.Drawing.Color.Purple;
            this.lblSTB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSTB.Location = new System.Drawing.Point(308, 243);
            this.lblSTB.Name = "lblSTB";
            this.lblSTB.Size = new System.Drawing.Size(118, 26);
            this.lblSTB.TabIndex = 11;
            this.lblSTB.Text = "Team B Score";
            this.lblSTB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSTA
            // 
            this.lblSTA.BackColor = System.Drawing.Color.GreenYellow;
            this.lblSTA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSTA.ForeColor = System.Drawing.Color.Black;
            this.lblSTA.Location = new System.Drawing.Point(31, 243);
            this.lblSTA.Name = "lblSTA";
            this.lblSTA.Size = new System.Drawing.Size(119, 26);
            this.lblSTA.TabIndex = 10;
            this.lblSTA.Text = "Team A Score";
            this.lblSTA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWinner
            // 
            this.lblWinner.ForeColor = System.Drawing.Color.DarkRed;
            this.lblWinner.Location = new System.Drawing.Point(142, 294);
            this.lblWinner.Name = "lblWinner";
            this.lblWinner.Size = new System.Drawing.Size(160, 29);
            this.lblWinner.TabIndex = 9;
            this.lblWinner.Text = "Winner is";
            this.lblWinner.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblFR
            // 
            this.lblFR.AutoSize = true;
            this.lblFR.Location = new System.Drawing.Point(179, 204);
            this.lblFR.Name = "lblFR";
            this.lblFR.Size = new System.Drawing.Size(86, 16);
            this.lblFR.TabIndex = 6;
            this.lblFR.Text = "Goal Score";
            this.lblFR.Click += new System.EventHandler(this.LblFR_Click);
            // 
            // btnPlay
            // 
            this.btnPlay.BackColor = System.Drawing.Color.White;
            this.btnPlay.ForeColor = System.Drawing.Color.Black;
            this.btnPlay.Location = new System.Drawing.Point(182, 132);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(75, 23);
            this.btnPlay.TabIndex = 5;
            this.btnPlay.Text = "Play";
            this.btnPlay.UseVisualStyleBackColor = false;
            this.btnPlay.Click += new System.EventHandler(this.BtnPlay_Click);
            // 
            // lblVS
            // 
            this.lblVS.AutoSize = true;
            this.lblVS.Location = new System.Drawing.Point(203, 56);
            this.lblVS.Name = "lblVS";
            this.lblVS.Size = new System.Drawing.Size(28, 16);
            this.lblVS.TabIndex = 4;
            this.lblVS.Text = "VS";
            // 
            // lblTB
            // 
            this.lblTB.AutoSize = true;
            this.lblTB.BackColor = System.Drawing.Color.Purple;
            this.lblTB.Location = new System.Drawing.Point(334, 56);
            this.lblTB.Name = "lblTB";
            this.lblTB.Size = new System.Drawing.Size(62, 16);
            this.lblTB.TabIndex = 3;
            this.lblTB.Text = "Team B";
            // 
            // lblTA
            // 
            this.lblTA.AutoSize = true;
            this.lblTA.BackColor = System.Drawing.Color.GreenYellow;
            this.lblTA.ForeColor = System.Drawing.Color.Black;
            this.lblTA.Location = new System.Drawing.Point(45, 56);
            this.lblTA.Name = "lblTA";
            this.lblTA.Size = new System.Drawing.Size(62, 16);
            this.lblTA.TabIndex = 2;
            this.lblTA.Text = "Team A";
            this.lblTA.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // imgTeamB
            // 
            this.imgTeamB.Location = new System.Drawing.Point(314, 91);
            this.imgTeamB.Name = "imgTeamB";
            this.imgTeamB.Size = new System.Drawing.Size(112, 95);
            this.imgTeamB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgTeamB.TabIndex = 1;
            this.imgTeamB.TabStop = false;
            // 
            // imgTeamA
            // 
            this.imgTeamA.Location = new System.Drawing.Point(31, 92);
            this.imgTeamA.Name = "imgTeamA";
            this.imgTeamA.Size = new System.Drawing.Size(108, 94);
            this.imgTeamA.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgTeamA.TabIndex = 0;
            this.imgTeamA.TabStop = false;
            // 
            // btnR
            // 
            this.btnR.BackColor = System.Drawing.Color.White;
            this.btnR.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnR.Location = new System.Drawing.Point(46, 298);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(75, 23);
            this.btnR.TabIndex = 2;
            this.btnR.Text = "RESET";
            this.btnR.UseVisualStyleBackColor = false;
            this.btnR.Click += new System.EventHandler(this.BtnR_Click);
            // 
            // btnC
            // 
            this.btnC.BackColor = System.Drawing.Color.White;
            this.btnC.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnC.Location = new System.Drawing.Point(175, 297);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(75, 23);
            this.btnC.TabIndex = 3;
            this.btnC.Text = "Close";
            this.btnC.UseVisualStyleBackColor = false;
            this.btnC.Click += new System.EventHandler(this.BtnC_Click);
            // 
            // grpCB
            // 
            this.grpCB.BackColor = System.Drawing.Color.Black;
            this.grpCB.Controls.Add(this.rbCheatBurn);
            this.grpCB.Controls.Add(this.rbCheatMan);
            this.grpCB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpCB.ForeColor = System.Drawing.Color.White;
            this.grpCB.Location = new System.Drawing.Point(547, 360);
            this.grpCB.Name = "grpCB";
            this.grpCB.Size = new System.Drawing.Size(213, 79);
            this.grpCB.TabIndex = 4;
            this.grpCB.TabStop = false;
            this.grpCB.Text = "Cheat Box";
            this.grpCB.Enter += new System.EventHandler(this.GroupBox1_Enter);
            // 
            // rbCheatBurn
            // 
            this.rbCheatBurn.AutoSize = true;
            this.rbCheatBurn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbCheatBurn.ForeColor = System.Drawing.Color.Purple;
            this.rbCheatBurn.Location = new System.Drawing.Point(6, 50);
            this.rbCheatBurn.Name = "rbCheatBurn";
            this.rbCheatBurn.Size = new System.Drawing.Size(110, 17);
            this.rbCheatBurn.TabIndex = 1;
            this.rbCheatBurn.TabStop = true;
            this.rbCheatBurn.Text = "Burnley Losses";
            this.rbCheatBurn.UseVisualStyleBackColor = true;
            this.rbCheatBurn.CheckedChanged += new System.EventHandler(this.RbCheatBurn_CheckedChanged);
            // 
            // rbCheatMan
            // 
            this.rbCheatMan.AutoSize = true;
            this.rbCheatMan.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbCheatMan.ForeColor = System.Drawing.Color.LawnGreen;
            this.rbCheatMan.Location = new System.Drawing.Point(7, 22);
            this.rbCheatMan.Name = "rbCheatMan";
            this.rbCheatMan.Size = new System.Drawing.Size(123, 17);
            this.rbCheatMan.TabIndex = 0;
            this.rbCheatMan.TabStop = true;
            this.rbCheatMan.Text = "Manchester Wins";
            this.rbCheatMan.UseVisualStyleBackColor = true;
            this.rbCheatMan.CheckedChanged += new System.EventHandler(this.RbCheatMan_CheckedChanged);
            // 
            // SoccerL
            // 
            this.AcceptButton = this.btnPlay;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = global::A1MaazShaikh.Properties.Resources.back;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.CancelButton = this.btnC;
            this.ClientSize = new System.Drawing.Size(772, 450);
            this.Controls.Add(this.grpCB);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.btnR);
            this.Controls.Add(this.grpSTM);
            this.Controls.Add(this.grpST);
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SoccerL";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Premier Soccer League";
            this.TransparencyKey = System.Drawing.Color.White;
            this.grpST.ResumeLayout(false);
            this.grpGB.ResumeLayout(false);
            this.grpGB.PerformLayout();
            this.grpGA.ResumeLayout(false);
            this.grpGA.PerformLayout();
            this.grpSTM.ResumeLayout(false);
            this.grpSTM.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgTeamB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgTeamA)).EndInit();
            this.grpCB.ResumeLayout(false);
            this.grpCB.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpST;
        private System.Windows.Forms.GroupBox grpGB;
        private System.Windows.Forms.GroupBox grpGA;
        private System.Windows.Forms.GroupBox grpSTM;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Label lblVS;
        private System.Windows.Forms.Label lblTB;
        private System.Windows.Forms.Label lblTA;
        private System.Windows.Forms.PictureBox imgTeamB;
        private System.Windows.Forms.PictureBox imgTeamA;
        private System.Windows.Forms.RadioButton rbMU;
        private System.Windows.Forms.Label lblFR;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.RadioButton rbWF;
        private System.Windows.Forms.Label lblWinner;
        private System.Windows.Forms.RadioButton rbAV;
        private System.Windows.Forms.RadioButton rbET;
        private System.Windows.Forms.RadioButton rbFH;
        private System.Windows.Forms.RadioButton rbCS;
        private System.Windows.Forms.RadioButton rbAS;
        private System.Windows.Forms.RadioButton rbBY;
        private System.Windows.Forms.RadioButton rbLP;
        private System.Windows.Forms.RadioButton rbSU;
        private System.Windows.Forms.Label lblSTB;
        private System.Windows.Forms.Label lblSTA;
        private System.Windows.Forms.GroupBox grpCB;
        private System.Windows.Forms.RadioButton rbCheatBurn;
        private System.Windows.Forms.RadioButton rbCheatMan;
    }
}


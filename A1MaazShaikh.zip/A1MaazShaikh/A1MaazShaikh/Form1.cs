﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A1MaazShaikh
{
    public partial class SoccerL : Form
    {

        public SoccerL()
        {
            InitializeComponent();
        }

        private void LblFR_Click(object sender, EventArgs e)
        {

        }

        private void BtnPlay_Click(object sender, EventArgs e)
        {
            RadioButton rb = new RadioButton();
            RadioButton rb1 = new RadioButton();

            //Random rnd = new Random();
            //int rndScore = rnd.Next(1, 8);
            //int rndScore1 = rnd.Next(1, 8);
            foreach (RadioButton radio in grpGA.Controls.OfType<RadioButton>())
            {
                if (radio.Checked)
                {
                    foreach (RadioButton radio1 in grpGB.Controls.OfType<RadioButton>())
                    {
                       
                            if (radio1.Checked)
                            {
                            if (mancheat == 1)
                            {
                                Random rnd = new Random();
                                int rndScore = rnd.Next(1, 8);
                                int rndScore1 = rnd.Next(0, 8);
                                int total = rndScore + rndScore1;
                                lblSTA.Text = total.ToString();
                                lblSTB.Text = rndScore1.ToString();
                                lblWinner.Text = radio.Text + " Wins";
                                
                            }
                            else if(burncheat == 1)
                            {
                                Random rnd = new Random();
                                int rndScore = rnd.Next(0, 8);
                                int rndScore1 = rnd.Next(3,8);
                                int sub = rndScore1 - 3;
                                lblSTA.Text = rndScore.ToString();
                                lblSTB.Text = sub.ToString();
                                lblWinner.Text = radio1.Text + " Losses";

                            }
                            else
                            {
                                Random rnd = new Random();
                                int rndScore = rnd.Next(1, 8);
                                int rndScore1 = rnd.Next(1, 8);
                                lblSTA.Text = rndScore.ToString();
                                lblSTB.Text = rndScore1.ToString();

                                if (rndScore > rndScore1)
                                {
                                    lblWinner.Text = radio.Text + " Wins";
                                }
                                else if (rndScore < rndScore1)
                                {
                                    lblWinner.Text = radio1.Text + " Wins";
                                }
                                else
                                {
                                    lblWinner.Text = "Its Draw";
                                }
                            }

                               
                            }
                        }
                        
                    }
                }
            }         


        private void BtnC_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void RbMU_CheckedChanged(object sender, EventArgs e)
        {
            imgTeamA.Image = Properties.Resources.manchester_united;
            lblTA.Text = "Manchester";
        }

       
        private void RbET_CheckedChanged(object sender, EventArgs e)
        {
            imgTeamA.Image = Properties.Resources.everton;
            lblTA.Text = "Everton";
        }

        private void RbWF_CheckedChanged(object sender, EventArgs e)
        {
            imgTeamA.Image = Properties.Resources.watford;
            lblTA.Text = "Watford";
        }

        private void RbAV_CheckedChanged(object sender, EventArgs e)
        {
            imgTeamA.Image = Properties.Resources.aston_villa;
            lblTA.Text = "Aston Villa";
        }

        private void RbFH_CheckedChanged(object sender, EventArgs e)
        {
            imgTeamA.Image = Properties.Resources.fulham;
            lblTA.Text = "Fulham";
        }

        private void RbSU_CheckedChanged(object sender, EventArgs e)
        {
            imgTeamB.Image = Properties.Resources.sheffield;
            lblTB.Text = "Sheffield";
        }

        private void RbLP_CheckedChanged(object sender, EventArgs e)
        {
            imgTeamB.Image = Properties.Resources.liverpool;
            lblTB.Text = "Liver Pool";
        }

        private void RbBY_CheckedChanged(object sender, EventArgs e)
        {
            imgTeamB.Image = Properties.Resources.burnley;
            lblTB.Text = "Burnley";
        }

        private void RbAS_CheckedChanged(object sender, EventArgs e)
        {
            imgTeamB.Image = Properties.Resources.arsenal;
            lblTB.Text = "Arsenal";
        }

        private void RbCS_CheckedChanged(object sender, EventArgs e)
        {
            imgTeamB.Image = Properties.Resources.chelsea;
            lblTB.Text = "Chelsea";
        }

        private void BtnR_Click(object sender, EventArgs e)
        {
            foreach (RadioButton radio in grpGA.Controls.OfType<RadioButton>())
            {
                foreach (RadioButton radio1 in grpGB.Controls.OfType<RadioButton>())
                {
                    radio.Checked = false;
                    radio1.Checked = false;
                   
                }

            }
            rbCheatMan.Checked = false;
            rbCheatBurn.Checked = false;
            lblTA.Text = "Team A";
            lblTB.Text = "Team B";
            lblSTA.Text = "";
            lblSTB.Text = "";
            lblWinner.Text = "";
            imgTeamA.Image = null;
            imgTeamB.Image = null;
        }

        private void GrpGA_Enter(object sender, EventArgs e)
        {
        }

        private void GroupBox1_Enter(object sender, EventArgs e)
        {

        }
     
        private void ChkMan_CheckedChanged(object sender, EventArgs e)
        {
        }

        int mancheat = 0;

        private void RbCheatMan_CheckedChanged(object sender, EventArgs e)
        {
            if (rbCheatMan.Checked)
            {
                mancheat = 1;
                rbET.Enabled = false;
                rbWF.Enabled = false;
                rbAV.Enabled = false;
                rbFH.Enabled = false;
            }
            else
            {
                mancheat = 0;
                rbET.Enabled = true;
                rbWF.Enabled = true;
                rbAV.Enabled = true;
                rbFH.Enabled = true;
            }
        }

        int burncheat = 0;
        private void RbCheatBurn_CheckedChanged(object sender, EventArgs e)
        {
            if (rbCheatBurn.Checked)
            {
                burncheat = 1;
                rbSU.Enabled = false;
                rbLP.Enabled = false;
                rbAS.Enabled = false;
                rbCS.Enabled = false;
            }
            else
            {
                burncheat = 0;
                rbSU.Enabled = true;
                rbLP.Enabled = true;
                rbAS.Enabled = true;
                rbCS.Enabled = true;
            }
        }
    }
}
